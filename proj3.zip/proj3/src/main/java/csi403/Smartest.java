package csi403;
// Import required java libraries
import java.io.*;
import java.util.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.json.*;

// Extend HttpServlet class
public class Smartest extends HttpServlet {
	
  // Standard servlet method 
  public void init() throws ServletException
  {
      // Do any required initialization here - likely none
  }

  // Standard servlet method - we will handle a POST operation
  public void doPost(HttpServletRequest request,
                    HttpServletResponse response)
            throws ServletException, IOException
  {
      doService(request, response); 
  }

  // Standard servlet method - we will not respond to GET
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
            throws ServletException, IOException
  {
      // Set response content type and return an error message
      response.setContentType("application/json");
      PrintWriter out = response.getWriter();
      out.println("{ 'message' : 'Use POST!'}");
  }


  // Our main worker method
  private void doService(HttpServletRequest request,
                    HttpServletResponse response)
            throws ServletException, IOException
  {
	  try{
	      // Get received JSON data from HTTP request
	      BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
	      String jsonStr = "";
	      if(br != null){
	          jsonStr = br.readLine();
	      }
	      
	      // Create JsonReader object
	      StringReader strReader = new StringReader(jsonStr);
	      JsonReader reader = Json.createReader(strReader);
	
	      // Get the singular JSON object (name:value pair) in this message.    
	      JsonObject obj = reader.readObject();
	      // From the object get the array named "inList"
	      JsonArray inArray = obj.getJsonArray("inList");
	      
	      List<String> list = new ArrayList<String>();
	      
	      for(int i = 0; i < inArray.size(); i++) {
	    	  JsonObject obj2 = inArray.getJsonObject(i);
	    	  for(int j = 0; j < obj2.size(); j++) {
	    		  JsonArray sArray = obj2.getJsonArray("smarter");
	    		  for(int k = 0; k < sArray.size(); k++) {
	    			  list.add(sArray.getString(k));
	    		  }
	    	  }
	      }
	      
	      //JsonArrayBuilder outArrayBuilder = Json.createArrayBuilder();
	      
	      // Set response content type to be JSON
	      response.setContentType("application/json");
	      // Send back the response JSON message
	      PrintWriter out = response.getWriter();
	      //out.println("{ \"outList\" : " + outArrayBuilder.build().toString() + "}"); 
	      for(int i = 0; i < list.size(); i++) {
				out.println(list.get(i));
	      }
	}catch(Exception e)
	  {
		PrintWriter out = response.getWriter();
		out.println("Error due to: " + e.getMessage());
	  }
  }

    
  // Standard Servlet method
  public void destroy()
  {
      // Do any required tear-down here, likely nothing.
  }
}

